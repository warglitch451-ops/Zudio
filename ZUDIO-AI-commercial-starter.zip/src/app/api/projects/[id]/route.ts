import {NextResponse} from "next/server";import {prisma} from "@/lib/prisma";
export async function DELETE(_r:Request,{params}:{params:Promise<{id:string}>}){try{const {id}=await params;await prisma.project.delete({where:{id}});return NextResponse.json({ok:true})}catch{return NextResponse.json({error:"Project missing or delete failed."},{status:404})}}
