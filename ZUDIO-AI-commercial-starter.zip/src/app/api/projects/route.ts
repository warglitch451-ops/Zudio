import {NextResponse} from "next/server";import {prisma} from "@/lib/prisma";
const orgId="zudio-bootstrap";
async function org(){return prisma.organization.upsert({where:{id:orgId},update:{},create:{id:orgId,name:"ZUDIO Workspace"}})}
export async function GET(){try{const o=await org();return NextResponse.json(await prisma.project.findMany({where:{organizationId:o.id},orderBy:{updatedAt:"desc"}}))}catch{return NextResponse.json({error:"Database unavailable. Configure DATABASE_URL and apply migrations."},{status:503})}}
export async function POST(req:Request){try{const b=await req.json();if(typeof b.name!=="string"||!b.name.trim())return NextResponse.json({error:"Name required"},{status:400});const o=await org();return NextResponse.json(await prisma.project.create({data:{name:b.name.trim().slice(0,100),brief:String(b.brief||"").slice(0,3000),organizationId:o.id}}),{status:201})}catch{return NextResponse.json({error:"Project create failed; database unavailable."},{status:503})}}
