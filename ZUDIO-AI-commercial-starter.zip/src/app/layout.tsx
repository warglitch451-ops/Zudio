import type {Metadata} from "next";import "./globals.css";
export const metadata:Metadata={title:"ZUDIO.AI — Agency Website Production OS",description:"AI-assisted website production workspace for agencies."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
