# ZUDIO.AI Commercial Starter

ZUDIO.AI is an AI-assisted agency website production starter. This archive contains a Next.js application, editable structured website document, browser-local project management, preview, HTML export, Gemini API route, and Prisma/PostgreSQL schema.

## Quick start
Requirements: Node.js 20+, npm, optionally PostgreSQL for the schema.
1. `npm install`
2. Copy `.env.example` to `.env`
3. Add `GEMINI_API_KEY` and optionally edit `GEMINI_MODEL` (default `gemini-2.5-flash`)
4. `npm run dev` then open http://localhost:3000

Database setup (schema included):
- `npx prisma generate`
- `npx prisma migrate dev --name init`

## Included working functionality
- Dashboard counters based on current browser workspace
- Create, rename, duplicate, delete projects
- Projects persist through browser localStorage (same browser/device profile)
- Structured site document, edit section heading/subheading/body/CTA and theme colors
- Add section and live preview
- AI edit endpoint calls Google Gemini, parses JSON document, updates preview
- HTML download/export
- Server-side environment key supported; session key can also be entered in AI Control Center
- Database project API and schema supplied for further integration

## Honest scope / not yet production-ready
This release is a commercial development starter, not a finished agency platform. Auth, tenant isolation, team/client collaboration, version snapshots and restore UI, e-commerce checkout/payment, browser QA, ZIP/React/Next export, domain/hosting integrations, 3D scene editor, usage-cost reporting, admin-only permission gating and robust server-side persistence integration are not completed. Projects currently use localStorage in the dashboard; database API routes/schema are scaffolding. Session key option means it is transmitted to the backend over the deployment's HTTPS connection and is not saved to local storage. Deploy with HTTPS only. Configure rate limits, auth, access controls and managed secrets before public launch or resale as a production system.

Never promise a successful payment or deployment unless the provider confirms it. Review code and test in your own environment before commercial delivery.
